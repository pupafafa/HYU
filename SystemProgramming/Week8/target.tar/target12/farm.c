/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_152(unsigned x)
{
    return x + 2428995912U;
}

void setval_396(unsigned *p)
{
    *p = 3347646715U;
}

unsigned addval_329(unsigned x)
{
    return x + 2496104776U;
}

unsigned addval_304(unsigned x)
{
    return x + 2425393240U;
}

void setval_409(unsigned *p)
{
    *p = 3281049755U;
}

unsigned addval_164(unsigned x)
{
    return x + 3281031256U;
}

void setval_376(unsigned *p)
{
    *p = 3347663040U;
}

void setval_297(unsigned *p)
{
    *p = 3281000666U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_215(unsigned x)
{
    return x + 3380926121U;
}

void setval_232(unsigned *p)
{
    *p = 3677932169U;
}

void setval_386(unsigned *p)
{
    *p = 3374372361U;
}

unsigned getval_202()
{
    return 3286272840U;
}

void setval_227(unsigned *p)
{
    *p = 3286272328U;
}

void setval_305(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_129()
{
    return 3225995913U;
}

void setval_188(unsigned *p)
{
    *p = 3380920745U;
}

unsigned getval_115()
{
    return 2425405833U;
}

unsigned getval_201()
{
    return 3222853257U;
}

unsigned getval_126()
{
    return 3675838089U;
}

unsigned getval_429()
{
    return 3351939512U;
}

unsigned getval_487()
{
    return 3531915657U;
}

unsigned addval_289(unsigned x)
{
    return x + 3683961481U;
}

unsigned addval_497(unsigned x)
{
    return x + 3353381192U;
}

unsigned getval_431()
{
    return 3523789197U;
}

unsigned getval_353()
{
    return 3525364361U;
}

unsigned addval_413(unsigned x)
{
    return x + 3281111689U;
}

unsigned addval_314(unsigned x)
{
    return x + 3353381192U;
}

void setval_449(unsigned *p)
{
    *p = 3224947369U;
}

void setval_169(unsigned *p)
{
    *p = 4022589129U;
}

unsigned addval_372(unsigned x)
{
    return x + 3375415689U;
}

void setval_424(unsigned *p)
{
    *p = 2497743176U;
}

unsigned getval_280()
{
    return 2429978934U;
}

unsigned addval_106(unsigned x)
{
    return x + 2445379939U;
}

unsigned getval_397()
{
    return 532928137U;
}

void setval_307(unsigned *p)
{
    *p = 2428603801U;
}

unsigned getval_331()
{
    return 3525364365U;
}

unsigned getval_336()
{
    return 3252717896U;
}

void setval_391(unsigned *p)
{
    *p = 3269495112U;
}

unsigned getval_211()
{
    return 3281114761U;
}

unsigned getval_257()
{
    return 3221275017U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
